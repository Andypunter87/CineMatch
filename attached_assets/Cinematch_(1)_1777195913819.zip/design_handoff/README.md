# Cinematch — Design Handoff

## Overview

This package contains hi-fi interactive prototypes for the Cinematch mobile app — an AI-powered film recommendation platform. The prototypes cover two main flows:

1. **Onboarding** (`Cinematch Prototype.html`) — cold-start user setup
2. **Recommender Loop** (`Cinematch Recommender.html`) — the core nightly use case

Also included: `Cinematch Wireframes.html` — the design exploration used to lock decisions. Reference this for context and alternatives, not for implementation.

---

## About the Design Files

The `.html` files in this bundle are **interactive design references built in HTML/React** — not production code. Your task is to **recreate these designs in the existing Cinematch React/TypeScript codebase**, using its established patterns, shadcn/ui components, Tailwind CSS, and Drizzle/Firestore data layer.

Do not ship the HTML files directly.

---

## Fidelity

**High-fidelity.** The prototypes are pixel-close to the intended final product. Implement them with this level of precision:
- Exact colours (tokens below)
- Exact typography (Caveat for display, Nunito for body, Space Mono for labels/meta)
- Exact spacing and border radius
- Interactions (swipe, drag, star rating, slot machine reels) should be implemented functionally

---

## Design Tokens

```ts
// Colors
const tokens = {
  paper:    '#FAF6EE',  // warm cream — primary background
  paper2:   '#F3ECDA',  // slightly darker cream — card backgrounds
  ink:      '#1A1A1A',  // near-black — all text and borders
  inkSoft:  '#4A4A4A',  // secondary text
  inkLight: '#8A8478',  // muted/label text

  pink:     '#FF4D8F',  // hot pink — primary accent (CTA, love/match)
  yellow:   '#FFC93C',  // sunshine — Cine mascot, highlights, mood card
  blue:     '#4D6EFF',  // electric blue — streaming chips, info
  mint:     '#5FD4A8',  // mint — group/social, positive
  lilac:    '#C9A7FF',  // lilac — secondary accent
  coral:    '#FF8C5A',  // coral — tense vibe bar, warm accents
};
```

```ts
// Typography
// Display / headlines: Caveat, weight 700
// Body / UI text:      Nunito, weight 400–700
// Labels / meta:       Space Mono, weight 400 or 700
// Load via Google Fonts:
// https://fonts.googleapis.com/css2?family=Caveat:wght@400;600;700&family=Nunito:wght@400;500;600;700&family=Space+Mono:wght@400;700
```

```ts
// Border radius
// Phone frame: 48px
// Cards: 14–18px
// Chips/pills: 100px (full round)
// Buttons: 100px (full round)
// Poster overlays: 8px

// Shadows (hard offset, brand style)
// Primary card:  5px 5px 0 #1A1A1A
// Secondary card: 3px 3px 0 #1A1A1A
// Small button:   2px 2px 0 #1A1A1A

// Borders
// All borders: 1.5px–2px solid #1A1A1A
// Dashed borders for secondary/unfocused: 1.5px dashed #1A1A1A
```

---

## Screens & Flows

### Flow 1: Onboarding (`Cinematch Prototype.html`)

#### Screen 1 — Welcome
- Full-height layout: row of 5 small striped poster placeholders (46×64px, rotated ±3°–6°) at top; title block; Cine intro card; CTA button at bottom
- Title: `cinematch` in Caveat 700 52px
- Subtitle: Nunito 14px, color `inkSoft`
- Cine card: `paper2` bg, 2px `ink` border, 3px 3px hard shadow; avatar (40px yellow circle, `C` in Caveat) + text
- CTA: `"create account to start →"` — full-width pill, `ink` bg, white Caveat 700 text, 3px shadow

#### Screen 2 — Auth / SSO
- Step label: `STEP 1 OF 2` in Space Mono 10px uppercase
- Headline: `create your account` Caveat 700 40px
- Body: Nunito 13px, color `inkSoft`
- **Google SSO button**: pill, white bg, 2px ink border, 3px shadow. Left: 32px circle with `G` in `#4285F4`. Label: Nunito 700 15px
- **Email option**: dashed border pill, transparent bg, Nunito 14px `inkSoft`
- Footer: Space Mono 9px, terms + privacy links
- *Note: Apple SSO removed per product decision*

#### Screen 3 — How It Works
- Step label: `STEP 2 OF 2`
- Mini demo card: striped poster (pink/coral/yellow), below it a 5-star rating row (circles, 32px, border `ink`)
- Cine speech bubble: paper2 bg, 1.5px ink border, `4px 14px 14px 14px` border-radius

#### Screen 4 — Swipe Taste Test (12 films)
**This is the most complex screen.**

- Progress bar: 6px tall, pink fill, ink border, 10px radius, animated width
- Cine prompt: 28px avatar + Nunito 13px question with film title in Caveat 700 17px
- Film card (270px wide): ink border 2px, 18px radius, 5px shadow
  - Poster area: 320px tall, striped gradient (film-specific), ink border 1.5px, 12px radius
  - Title overlay (absolute, bottom 10px): `rgba(250,246,238,.93)` bg, ink border 1.5px, 8px radius, film title in Caveat 700 22px, meta in Space Mono 8px uppercase
  - Blurb below poster: Nunito 12px, `inkSoft`
- **5-star rating row**: paper2 card (2px border, 3px shadow). Five 50×50px circle buttons. On hover/select: `pink` bg, white star, `translate(-1px,-1px)`, 2px shadow. Labels: Space Mono 8px `meh` / `loved it`
- **"haven't seen it?"** button: dashed border, 100px radius, Nunito 13px, full width
- **Swipe/drag mechanic**: drag card left/right; at 80px threshold card flies off (500px translate + 25° rotate, 320ms transition). LOVE stamp (pink, rotate 14°) and SKIP stamp (inkSoft, rotate -14°) fade in on drag

#### Screen 5 — Cinematic Fingerprint
- Computed from ratings: tags weighted by star score (4★ > 1★), top tags derive nickname e.g. `"Bittersweet + Romantic"`
- **Fingerprint card** (270px, 9:14 ratio): gradient `pink → coral → yellow`, 2px ink border, 6px shadow, rotate -1.5deg
  - Header: `CINEMATCH FINGERPRINT` Space Mono 8px
  - Nickname: Caveat 700 30px
  - 3 mini signature posters (52×76px, rotated ±5°)
  - DNA traits: 3 pill rows (tone / style / pace), each `rgba(250,246,238,.6)` bg + ink border 1.5px, Caveat 700 15px value
  - `#001` stamp: yellow bg, rotate 18°
- Cine speech bubble with personalised analysis
- Liked films listed as chips
- CTAs: `"find my first film →"` (primary ink) + `"↻ start over"` + `"↗ share card"`

---

### Flow 2: Recommender Loop (`Cinematch Recommender.html`)

#### Screen 1 — Fork
- `"who's watching?"` — Caveat 700 46px
- Two large tappable cards:
  - **Just me** (yellow bg, -0.5° rotation, 4px shadow): routes to slot machine
  - **Me + someone** (pink bg, +0.5° rotation, 4px shadow): routes to group invite
- Cine speech bubble at bottom

#### Screen 2a — Slot Machine (Solo + Group)
- Header: back button + context label (`just me` or `group · 3 people`)
- Headline: `"spin your mood"` or `"what's the group vibe?"`
- **4 reels** (FEEL / FLAVOUR / LENGTH / ERA):
  - Each reel: coloured header bar (pink/blue/yellow/mint), `n/of` count top-right in Space Mono 10px
  - Lock button (30px circle, yellow bg when locked 🔒, paper when unlocked 🔓)
  - Option strip: current option Caveat 700 24px centred, adjacent options 16px opacity .25
  - Arrow buttons (24×24px, 6px radius): ‹ ›
  - Dot pagination: active dot 10×4px, inactive 4×4px, all 4px radius, gap 3px
- **Cine readback**: paper bg, dashed border, reads current FEEL + FLAVOUR + LENGTH live
- **Actions**: `🎲 ROLL` (outline) + `🎬 find it →` (ink primary), both 100px radius

#### Screen 2b — Cine Loading
- Cine avatar 80px, animated ellipsis
- `"finding something perfect…"` Caveat 700 30px
- `"finding you the perfect watch"` Nunito 14px
- Best match preview card: paper bg, 2px ink border, 14px radius, 3px shadow — shows film title + streaming info
- **Auto-advances after 2.2 seconds**

#### Screen 3 — Movie Detail (Swipeable deck of 5)
- Header: back button, `"1 of 5"` counter, save ♡ button
- Dot pagination (5 dots): active dot 18×6px pink, inactive 6×6px inkLight
- Card stack: back card rotated 2° with 8px Y offset, 45% opacity
- Front card (flex, fills available height):
  - Poster: fills remaining height, striped gradient, ink border 1.5px, 12px radius
  - Title overlay: absolute, bottom 10px, `rgba(250,246,238,.93)` bg, Caveat 700 24px
  - Chips row: streaming (blue bg), runtime (paper), rating (paper) — 100px radius, ink border, Nunito 11px
  - **Cine "why" callout**: yellow bg, 1.5px ink border, 10px radius, Space Mono 9px label `"cine says ✦"`, Nunito 12px quote
  - **Vibe bars** (4 bars: cosy/funny/thinky/tense): label Nunito 11px `inkSoft`, 7px tall bar with colour fill, number value
- **LOVE / SKIP stamps**: absolute positioned, appear on drag (opacity scales 0→1 at 80px threshold)
- **Actions**: `"← next pick"` (outline) + `"▶ watch it"` (ink primary) — both 100px radius
- Swipe hint: Space Mono 8px below buttons
- **"Watch it" behaviour**: logs choice to `/api/watch-choices`, shows `"opening…"` state, routes to rating screen, then opens streaming platform in new tab after rating

#### Screen 4 — Post-Watch Rating
- Same 5-star mechanic as onboarding
- Cine speech bubble: `"good choice? give it some stars and i'll get better at this 🌟"`
- On star tap: opens streaming platform URL → then shows Mood Card Drop

#### Screen 5 — Mood Card Drop
- **Trigger**: always on first rating per session (production: 1–4× per month, random interval)
- Step 1 — Teaser: yellow card (rotate -0.8°, 4px shadow), `"RARE DROP ✦"` Space Mono, title + description. Buttons: `"reveal card →"` (ink primary) + `"later"` (outline)
- Step 2 — Reveal: portrait card (270px, 9:14, gradient pink→coral→yellow, rotate -1.5°, 6px shadow)
  - `CINEMATCH · APR '26` Space Mono 8px
  - Mood name: `"Bittersweet & Beautiful"` Caveat 700 28px
  - 3 mini poster thumbnails (rotated)
  - Top picks list (Nunito 10px)
  - `APR 2026` stamp rotated 18°
- Buttons: `"↗ share"` (ink primary) + `"save"` + `"find another film →"` (outline)
- Footer: `"next drop: sometime in may 🎲"` Space Mono 8px

---

### Flow 3: Group Session

#### G1 — Invite / Waiting Room
- Live member status (3 avatars with ✓/… badge, colour per member)
- Status bar: paper2 → yellow transition when all ready
- Session link display: `cinematch.co/g/FR1DAY`
- **"↗ invite"** button: triggers `navigator.share()` (native iOS share sheet) with pre-written message `"hey! join me on Cinematch tonight 🎬 pick a film together → cinematch.co/g/FR1DAY"`. Fallback: opens WhatsApp Web
- **"let's pick! →"** button: **disabled** (paper2 bg, inkLight) until all members ready, then enabled (ink bg, white)
- `"👁 preview: how Tay sees the invite"` — dashed outline button, routes to notification screen
- **Real-time behaviour**: member status updates via Firestore listener; simulate with polling in dev

#### G2 — Lock Screen Notification (Invitee)
- Full-screen dark blue gradient: `#1A1A2E → #16213E → #0F3460`
- Time: Caveat 700 72px white
- Date: Nunito 15px, `rgba(255,255,255,.7)`
- Notification card: `rgba(255,255,255,.18)` bg, `blur(20px)` backdrop filter, `1px rgba(255,255,255,.25)` border, 20px radius
  - App icon: 40px yellow circle, `C` Caveat 700
  - Title: Nunito 700 13px white + `"now"` Space Mono 10px
  - Message: Nunito 700 14px white
  - Sub-message: Nunito 12px `rgba(255,255,255,.8)`
  - Action buttons: `"Dismiss"` (glass bg) + `"Join session →"` (yellow bg, ink text)

#### G3 — Join Session (Invitee)
- `"you're invited"` Space Mono label + `"film night 🎬"` Caveat 700 40px
- Host message in speech bubble (pink avatar A + paper2 bubble)
- Member status card (same as host view but Tay is `isMe`)
- Cine speech bubble explaining the group mechanic
- `"i'm in! 🙌"` button: ink bg → paper2 when joining

#### G4 — Group Slot Machine
- Same slot machine UI as solo
- Headline: `"what's the group vibe?"`
- Subtitle: `"set tonight's vibe — i'll blend everyone's taste to find the best match"`
- **Match algorithm**: `matchFilmsGroup()` — blends vibe weights with averaged group member taste profiles (cosy/thinky/funny/tense/romantic per member)

---

## Film Catalogue

12 curated films, each with:
- `id`, `title`, `year`, `director`
- `tags`: mood descriptors used to build fingerprint
- `blurb`: one-line summary for the card
- `why`: vibe scores `{ cosy, thinky, funny, tense, romantic }` (0–100) used for matching
- `streaming`: platform name
- `runtime`, `rating`
- `colors`: [c1, c2, c3] for striped poster generation
- `stripe`: pattern type (`horizontal`, `diagonal`, `vertical`, `burst`, `flame`, `splash`, `neon`)

**The 12 films**: The Grand Budapest Hotel, Moonlight, Everything Everywhere All at Once, Past Lives, Parasite, Hot Fuzz, In the Mood for Love, The Worst Person in the World, Drive, Paddington 2, Portrait of a Lady on Fire, Columbus.

Full catalogue with all data: see `Cinematch Recommender.html` → `const FILMS = [...]` at the top of the first `<script>` block.

---

## Interactions & Behaviour

| Interaction | Detail |
|---|---|
| Card drag/swipe | `onMouseDown/TouchStart` → track delta → threshold 80px → fly off (500px + 25° rotate, 280ms ease-out) |
| Slot reel scrub | Touch swipe ↔ ≥30px OR arrow buttons OR click to select; dots update |
| Lock/unlock reel | Toggles locked state; 🎲 ROLL skips locked reels |
| ROLL button | Randomises unlocked reels with 8-step animation at 80ms intervals |
| 5-star rating | Hover preview + tap to confirm; stars fill pink left-to-right |
| "Watch it" | DB log → route to rating screen → star tap → open streaming URL + show mood card |
| Mood card reveal | Two-step: teaser → reveal with share/save CTAs |
| Group live status | Firestore `onSnapshot` on session doc; member status `waiting → ready` |
| Native share | `navigator.share()` with title/text/url; fallback to WhatsApp Web |
| Push notification | APNs via Firebase Cloud Messaging; deep-link to `/join?session=FR1DAY` |

---

## State Management

The app uses Firestore for real-time group session state. Key collections:

```
/sessions/{sessionId}
  members: { userId: { name, ready, taste } }
  status: 'waiting' | 'spinning' | 'picked'
  vibe: { feel, flavour, length, era }
  picks: [filmId × 5]

/users/{userId}
  fingerprint: { tags, topFilms, avgRating }
  ratings: { [filmId]: 1–5 }
  moodCards: [{ month, nickname, films, sharedAt }]
  watchChoices: [{ filmId, vibe, ts }]
```

---

## API Endpoints to Implement

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/watch-choices` | POST | Log `{ filmId, vibe, ts }` when user taps "Watch it" |
| `/api/match` | POST | Server-side film matching (body: `{ reels, userId, groupId? }`) |
| `/api/mood-card/generate` | POST | Trigger mood card generation (existing endpoint) |
| `/api/sessions` | POST | Create group session, returns `sessionId` |
| `/api/sessions/:id/join` | POST | Mark member as ready |

---

## Assets

- **Poster placeholders**: Generated via CSS gradients using each film's `colors` array and `stripe` pattern. No image assets required — this is intentional brand style.
- **Cine mascot**: Yellow circle (`#FFC93C`), 2px `#1A1A1A` border, `"C"` in Caveat 700. No image asset — pure CSS/div.
- **Fonts**: Load from Google Fonts (see token section above).
- **Icons**: None — all UI icons are Unicode characters or emoji (★ ♥ ♡ ← → 🎬 🎲 🔒 🔓 ✦ ✓).

---

## Files in This Package

| File | Purpose |
|---|---|
| `Cinematch Prototype.html` | Onboarding flow prototype (welcome → auth → taste test → fingerprint) |
| `Cinematch Recommender.html` | Recommender loop prototype (fork → slot machine → detail → rating → mood card; group flow) |
| `Cinematch Wireframes.html` | Design exploration — locked decisions, alternative directions, design notes |
| `README.md` | This document |

---

## Notes for the Developer

1. **Shadcn/ui**: The existing codebase uses shadcn/ui. Adapt the custom components (Btn, Chip, VibeBars, etc.) to use shadcn primitives where appropriate — but override styles to match the token system above rather than shadcn defaults.

2. **Tailwind**: Use Tailwind for layout and spacing; add the custom tokens to `tailwind.config.ts` under `colors` and `fontFamily`.

3. **Fingerprint algorithm**: Implemented in `fingerprint.jsx` inside the prototype. Port the tag-weighting logic server-side so it can power both the onboarding summary and the recommender.

4. **Group session real-time**: The prototype simulates Tay joining after 4 seconds. Replace with a Firestore `onSnapshot` listener on `/sessions/{sessionId}/members`.

5. **Push notifications**: The lock screen UI is in `NotificationScreen` in `Cinematch Recommender.html`. Wire to Firebase Cloud Messaging + APNs for production.

6. **Streaming redirects**: `getStreamingUrl()` in the prototype maps platform names to search URLs. Replace with direct deep-links where available (e.g., `netflix://` scheme).

7. **Mood card generation**: The card design is in `MoodCardDrop` in `Cinematch Recommender.html`. The existing `Placid` + `OpenAI` backend is already wired — connect the frontend reveal flow to `/api/mood-card/generate`.
